package com.profitlense;

import javafx.animation.*;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyCode; // Import for Enter key
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.util.ArrayList;
import java.util.Arrays; // <-- ADD THIS LINE

import java.io.*;
import java.util.HashMap; // Import for user map
import java.util.List;
import java.util.Map; // Import for user map
import java.util.stream.Collectors;

// Imports for reading from resources
import java.io.InputStream;
import java.io.InputStreamReader;


public class LoginApp extends Application {

    // --- User credentials map ---
    private Map<String, String> userCredentials = new HashMap<>();
    private final File userFile = new File("src/main/resources/user.csv");

    private StackPane root;
    private HBox loginPane, signupPane;

    // --- UI Fields (for Dashboard) ---
    private Label reportDistrictLabel, reportInvestmentLabel, suggestionTextLabel;
    private Label source1DetailLabel, source2DetailLabel, source3DetailLabel;
    private PieChart profitPieChart;
    private ObservableList<PieChart.Data> pieChartData;


    @Override
    public void start(Stage stage) {
        root = new StackPane();
        root.setAlignment(Pos.CENTER);

        loadUsers(); // Load users from user.csv

        loginPane = createLoginScreen(stage);
        signupPane = createSignupScreen(stage);

        root.getChildren().add(loginPane);
        root.setStyle("-fx-background-color: #FFFFFF;");
        Scene scene = new Scene(root, 900, 650);

        stage.setScene(scene);
        stage.setTitle("ProfitLense");
        stage.show();
    }

    // --- Loads default admins and all users from user.csv ---
    private void loadUsers() {
        // 1. Add default admin accounts
        userCredentials.put("fahim@gmail.com", "admin123");
        userCredentials.put("talha@gmail.com", "admin123");
        userCredentials.put("sanjida@gmail.com", "admin123");

        // 2. Try to load users from user.csv
        try (InputStream is = new FileInputStream(userFile)) {
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("email,password") || line.trim().isEmpty()) {
                    continue; // Skip header or empty lines
                }
                String[] parts = line.split(",");
                if (parts.length >= 2) {
                    userCredentials.put(parts[0], parts[1]);
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("user.csv not found. Creating a new one.");
            saveUser("email,password", ""); // Creates the file with a header
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // --- Creates the consistent left-side panel ---
    private VBox createLeftPane(String title, String subtitle) {
        VBox leftPane = new VBox(10);
        leftPane.setStyle("-fx-background-color: #243B55;"); // Dark blue color
        leftPane.setAlignment(Pos.CENTER_LEFT);
        leftPane.setPadding(new Insets(40));

        Label titleLabel = new Label(title);
        titleLabel.setFont(Font.font("Arial", FontWeight.BOLD, 32));
        titleLabel.setTextFill(Color.WHITE);
        titleLabel.setWrapText(true);

        Label subtitleLabel = new Label(subtitle);
        subtitleLabel.setFont(Font.font("Arial", FontWeight.NORMAL, 16));
        subtitleLabel.setTextFill(Color.web("#B0C4DE")); // Light blue-gray
        subtitleLabel.setWrapText(true);

        leftPane.getChildren().addAll(titleLabel, subtitleLabel);
        return leftPane;
    }

    // --- Creates the right-side form for login ---
    private BorderPane createLoginRightPane(Stage stage, HBox signupLinkBox) {
        Label title = new Label("Login");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 28));
        title.setTextFill(Color.BLACK);

        // --- Email Field ---
        Label emailLabel = new Label("Username or Email");
        emailLabel.setFont(Font.font("Arial", FontWeight.NORMAL, 14));
        TextField emailField = new TextField();
        emailField.setPromptText("Enter your email");
        emailField.setStyle("-fx-font-size: 14px;");
        VBox emailBox = new VBox(5, emailLabel, emailField);

        // --- Password Field (with Show/Hide) ---
        Label passLabel = new Label("Password");
        passLabel.setFont(Font.font("Arial", FontWeight.NORMAL, 14));

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Enter your password");
        passwordField.setStyle("-fx-font-size: 14px;");

        TextField visiblePasswordField = new TextField(); // For show password
        visiblePasswordField.setPromptText("Enter your password");
        visiblePasswordField.setStyle("-fx-font-size: 14px;");

        visiblePasswordField.setManaged(false);
        visiblePasswordField.setVisible(false);

        StackPane passwordContainer = new StackPane(passwordField, visiblePasswordField);
        VBox passwordBox = new VBox(5, passLabel, passwordContainer);

        // --- Options ---
        CheckBox rememberMe = new CheckBox("Remember Me");
        CheckBox showPassword = new CheckBox("Show Password"); // <-- NEW
        Hyperlink forgotPassword = new Hyperlink("Forgot Password?");
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        // --- Bind show/hide logic ---
        visiblePasswordField.managedProperty().bind(showPassword.selectedProperty());
        visiblePasswordField.visibleProperty().bind(showPassword.selectedProperty());
        passwordField.managedProperty().bind(showPassword.selectedProperty().not());
        passwordField.visibleProperty().bind(showPassword.selectedProperty().not());
        visiblePasswordField.textProperty().bindBidirectional(passwordField.textProperty());

        HBox optionsBox = new HBox(10, rememberMe, showPassword); // <-- Added showPassword
        HBox optionsBox2 = new HBox(0, spacer, forgotPassword);

        Label message = new Label();
        message.setTextFill(Color.RED);
        message.setPadding(new Insets(5, 0, 5, 0));

        Button loginBtn = new Button("Login");
        loginBtn.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        loginBtn.setTextFill(Color.WHITE);
        loginBtn.setMaxWidth(Double.MAX_VALUE);
        loginBtn.setStyle("-fx-background-color: #0078D7; -fx-background-radius: 5; -fx-padding: 10 20; -fx-cursor: hand;");
        loginBtn.setOnMouseEntered(e -> loginBtn.setStyle("-fx-background-color: #005A9E; -fx-text-fill: white; -fx-font-size: 14px; -fx-font-weight: bold; -fx-padding: 10 20; -fx-background-radius: 5; -fx-cursor: hand;"));
        loginBtn.setOnMouseExited(e -> loginBtn.setStyle("-fx-background-color: #0078D7; -fx-text-fill: white; -fx-font-size: 14px; -fx-font-weight: bold; -fx-padding: 10 20; -fx-background-radius: 5; -fx-cursor: hand;"));

        // --- Login Logic as a Runnable ---
        Runnable loginAction = () -> {
            String email = emailField.getText().trim();
            String pass = passwordField.getText().trim();

            // --- Check against the loaded user map ---
            if (userCredentials.containsKey(email) && userCredentials.get(email).equals(pass)) {
                message.setTextFill(Color.GREEN);
                message.setText("Login Successful!");
                loadDashboard(stage);
            } else {
                message.setTextFill(Color.RED);
                message.setText("Invalid email or password!");
            }
        };

        loginBtn.setOnAction(e -> loginAction.run());

        // --- Login on Enter Key ---
        emailField.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.ENTER) loginAction.run();
        });
        passwordField.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.ENTER) loginAction.run();
        });
        visiblePasswordField.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.ENTER) loginAction.run();
        });

        // --- Form Container ---
        VBox formContainer = new VBox(20, title, emailBox, passwordBox, optionsBox, optionsBox2, loginBtn, message);
        formContainer.setAlignment(Pos.CENTER_LEFT);
        formContainer.setMaxWidth(350);
        formContainer.setPadding(new Insets(40));

        BorderPane rightPane = new BorderPane();
        rightPane.setStyle("-fx-background-color: white;");
        rightPane.setCenter(formContainer);
        rightPane.setBottom(signupLinkBox);
        BorderPane.setAlignment(signupLinkBox, Pos.CENTER);
        BorderPane.setMargin(signupLinkBox, new Insets(0, 0, 30, 0));

        return rightPane;
    }

    // --- Creates the right-side form for signup ---
    private BorderPane createSignupRightPane(HBox loginLinkBox) {
        Label title = new Label("Sign Up");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 28));
        title.setTextFill(Color.BLACK);

        Label emailLabel = new Label("Email");
        TextField emailField = new TextField();
        emailField.setPromptText("Enter your email");
        emailField.setStyle("-fx-font-size: 14px;");
        VBox emailBox = new VBox(5, emailLabel, emailField);

        // --- Password Field (with Show/Hide) ---
        Label passLabel = new Label("Password");
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Create a password");
        passwordField.setStyle("-fx-font-size: 14px;");
        TextField visiblePasswordField = new TextField();
        visiblePasswordField.setPromptText("Create a password");
        visiblePasswordField.setStyle("-fx-font-size: 14px;");
        visiblePasswordField.setManaged(false);
        visiblePasswordField.setVisible(false);
        StackPane passwordContainer = new StackPane(passwordField, visiblePasswordField);
        VBox passwordBox = new VBox(5, passLabel, passwordContainer);

        // --- Confirm Password Field (with Show/Hide) ---
        Label confirmLabel = new Label("Confirm Password");
        PasswordField confirmPassword = new PasswordField();
        confirmPassword.setPromptText("Confirm your password");
        confirmPassword.setStyle("-fx-font-size: 14px;");
        TextField visibleConfirmField = new TextField();
        visibleConfirmField.setPromptText("Confirm your password");
        visibleConfirmField.setStyle("-fx-font-size: 14px;");
        visibleConfirmField.setManaged(false);
        visibleConfirmField.setVisible(false);
        StackPane confirmContainer = new StackPane(confirmPassword, visibleConfirmField);
        VBox confirmBox = new VBox(5, confirmLabel, confirmContainer);

        // --- Show Password Checkbox ---
        CheckBox showPassword = new CheckBox("Show Password");

        // Bind show/hide logic for BOTH password fields
        visiblePasswordField.managedProperty().bind(showPassword.selectedProperty());
        visiblePasswordField.visibleProperty().bind(showPassword.selectedProperty());
        passwordField.managedProperty().bind(showPassword.selectedProperty().not());
        passwordField.visibleProperty().bind(showPassword.selectedProperty().not());
        visiblePasswordField.textProperty().bindBidirectional(passwordField.textProperty());

        visibleConfirmField.managedProperty().bind(showPassword.selectedProperty());
        visibleConfirmField.visibleProperty().bind(showPassword.selectedProperty());
        confirmPassword.managedProperty().bind(showPassword.selectedProperty().not());
        confirmPassword.visibleProperty().bind(showPassword.selectedProperty().not());
        visibleConfirmField.textProperty().bindBidirectional(confirmPassword.textProperty());

        Label message = new Label();
        message.setTextFill(Color.RED);
        message.setPadding(new Insets(5, 0, 5, 0));

        Button signupBtn = new Button("Create Account");
        signupBtn.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        signupBtn.setTextFill(Color.WHITE);
        signupBtn.setMaxWidth(Double.MAX_VALUE);
        signupBtn.setStyle("-fx-background-color: #0078D7; -fx-background-radius: 5; -fx-padding: 10 20; -fx-cursor: hand;");
        signupBtn.setOnMouseEntered(e -> signupBtn.setStyle("-fx-background-color: #005A9E; -fx-text-fill: white; -fx-font-size: 14px; -fx-font-weight: bold; -fx-padding: 10 20; -fx-background-radius: 5; -fx-cursor: hand;"));
        signupBtn.setOnMouseExited(e -> signupBtn.setStyle("-fx-background-color: #0078D7; -fx-text-fill: white; -fx-font-size: 14px; -fx-font-weight: bold; -fx-padding: 10 20; -fx-background-radius: 5; -fx-cursor: hand;"));

        signupBtn.setOnAction(e -> {
            String email = emailField.getText().trim();
            String pass = passwordField.getText().trim();

            if (email.isEmpty() || pass.isEmpty() || confirmPassword.getText().isEmpty()) {
                message.setTextFill(Color.RED);
                message.setText("All fields required!");
            } else if (!pass.equals(confirmPassword.getText())) {
                message.setTextFill(Color.RED);
                message.setText("Passwords do not match!");
            } else if (userCredentials.containsKey(email)) {
                message.setTextFill(Color.RED);
                message.setText("This email is already registered.");
            } else {
                saveUser(email, pass); // Saves to file AND map
                message.setTextFill(Color.GREEN);
                message.setText("Signup Successful! You can now log in.");
                emailField.clear();
                passwordField.clear();
                confirmPassword.clear();
            }
        });

        VBox formContainer = new VBox(20, title, emailBox, passwordBox, confirmBox, showPassword, signupBtn, message);
        formContainer.setAlignment(Pos.CENTER_LEFT);
        formContainer.setMaxWidth(350);
        formContainer.setPadding(new Insets(40));

        BorderPane rightPane = new BorderPane();
        rightPane.setStyle("-fx-background-color: white;");
        rightPane.setCenter(formContainer);
        rightPane.setBottom(loginLinkBox);
        BorderPane.setAlignment(loginLinkBox, Pos.CENTER);
        BorderPane.setMargin(loginLinkBox, new Insets(0, 0, 30, 0));

        return rightPane;
    }


    // --- Creates the entire Login Screen HBox ---
    private HBox createLoginScreen(Stage stage) {
        HBox loginScreen = new HBox();
        Hyperlink toSignup = new Hyperlink("Sign Up");
        toSignup.setOnAction(e -> switchPane(signupPane, loginPane));
        HBox signupLinkBox = new HBox(5, new Label("Don't have an account?"), toSignup);
        signupLinkBox.setAlignment(Pos.CENTER);
        VBox leftPane = createLeftPane("Welcome to ProfitLense", "Analyze your profit");
        BorderPane rightPane = createLoginRightPane(stage, signupLinkBox);
        leftPane.prefWidthProperty().bind(root.widthProperty().multiply(0.5));
        rightPane.prefWidthProperty().bind(root.widthProperty().multiply(0.5));
        loginScreen.getChildren().addAll(leftPane, rightPane);
        return loginScreen;
    }

    // --- Creates the entire Signup Screen HBox ---
    private HBox createSignupScreen(Stage stage) {
        HBox signupScreen = new HBox();
        Hyperlink toLogin = new Hyperlink("Login");
        toLogin.setOnAction(e -> switchPane(loginPane, signupPane));
        HBox loginLinkBox = new HBox(5, new Label("Already have an account?"), toLogin);
        loginLinkBox.setAlignment(Pos.CENTER);
        VBox leftPane = createLeftPane("Create your Account", "Get started with ProfitLense");
        BorderPane rightPane = createSignupRightPane(loginLinkBox);
        leftPane.prefWidthProperty().bind(root.widthProperty().multiply(0.5));
        rightPane.prefWidthProperty().bind(root.widthProperty().multiply(0.5));
        signupScreen.getChildren().addAll(leftPane, rightPane);
        return signupScreen;
    }


    // --- Saves to file AND updates the live map ---
    private void saveUser(String email, String password) {
        // 1. Write to file
        try {
            userFile.getParentFile().mkdirs();
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(userFile, true))) {
                if (email.equals("email,password")) {
                    writer.write("email,password");
                } else {
                    writer.write(email + "," + password);
                }
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // 2. Update the live map
        if (!email.equals("email,password")) {
            userCredentials.put(email, password);
        }
    }

    // --- (UNCHANGED) ---
    private void switchPane(Pane show, Pane hide) {
        if (!root.getChildren().contains(show)) root.getChildren().add(show);
        show.setOpacity(0);
        show.setScaleX(0.8);
        show.setScaleY(0.8);

        Timeline fadeIn = new Timeline(
                new KeyFrame(Duration.seconds(0.6),
                        new KeyValue(show.opacityProperty(), 1, Interpolator.EASE_BOTH),
                        new KeyValue(show.scaleXProperty(), 1, Interpolator.EASE_OUT),
                        new KeyValue(show.scaleYProperty(), 1, Interpolator.EASE_OUT)
                )
        );

        Timeline fadeOut = new Timeline(
                new KeyFrame(Duration.seconds(0.6),
                        new KeyValue(hide.opacityProperty(), 0, Interpolator.EASE_BOTH),
                        new KeyValue(hide.scaleXProperty(), 0.8, Interpolator.EASE_IN),
                        new KeyValue(hide.scaleYProperty(), 0.8, Interpolator.EASE_IN)
                )
        );

        fadeOut.setOnFinished(e -> root.getChildren().remove(hide));
        new ParallelTransition(fadeIn, fadeOut).play();
    }

    // ---------------- DASHBOARD ----------------
    // (This code from here down is unchanged)
    private void loadDashboard(Stage stage) {
        BorderPane dashboard = new BorderPane();
        dashboard.setStyle(String.format("-fx-background-color: linear-gradient(to right, %s, %s);", "#141E30", "#243B55"));

        VBox sidebar = new VBox(20);
        sidebar.setStyle("-fx-background-color: rgba(0,0,0,0.6); -fx-background-radius: 0 20 20 0;");
        sidebar.setPadding(new Insets(30));
        sidebar.setPrefWidth(200);

        Label title = new Label("ProfitLense");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 22));
        title.setTextFill(Color.WHITE);

        Button homeBtn = new Button("🏠 Home");
        Button graphBtn = new Button("📊 Graph");
        Button suggestionBtn = new Button("💡 Suggestion");

        String btnIdle = String.format("-fx-background-color: transparent; -fx-font-size: 15px; -fx-text-fill: %s; -fx-alignment: CENTER_LEFT; -fx-padding: 10 15; -fx-font-weight: bold; -fx-background-radius: 8; -fx-cursor: hand;", "#FFFFFF");
        String btnHover = String.format("-fx-background-color: %s; -fx-font-size: 15px; -fx-text-fill: %s; -fx-alignment: CENTER_LEFT; -fx-padding: 10 15; -fx-font-weight: bold; -fx-background-radius: 8; -fx-cursor: hand;", "#0078D7", "#FFFFFF");

        for (Button b : Arrays.asList(homeBtn, graphBtn, suggestionBtn)) {
            b.setMaxWidth(Double.MAX_VALUE);
            b.setStyle(btnIdle);
            b.setOnMouseEntered(e -> b.setStyle(btnHover));
            b.setOnMouseExited(e -> b.setStyle(btnIdle));
        }

        sidebar.getChildren().addAll(title, homeBtn, graphBtn, suggestionBtn);
        dashboard.setLeft(sidebar);

        StackPane contentArea = new StackPane();
        contentArea.setAlignment(Pos.CENTER);
        dashboard.setCenter(contentArea);

        Scene scene = root.getScene();
        scene.setRoot(dashboard);

        VBox homePage = createHomePage();
        VBox graphPage = createGraphPage();
        VBox suggestionPage = createSuggestionPage();

        homeBtn.setOnAction(e -> {
            if (!contentArea.getChildren().contains(homePage)) {
                contentArea.getChildren().setAll(homePage);
            }
        });
        graphBtn.setOnAction(e -> {
            if (!contentArea.getChildren().contains(graphPage)) {
                contentArea.getChildren().setAll(graphPage);
            }
        });
        suggestionBtn.setOnAction(e -> {
            if (!contentArea.getChildren().contains(suggestionPage)) {
                contentArea.getChildren().setAll(suggestionPage);
            }
        });

        contentArea.getChildren().add(homePage);
    }


    // ---------------- HOME PAGE ----------------
    private VBox createHomePage() {
        VBox box = new VBox(15);
        box.setAlignment(Pos.CENTER);
        box.setPadding(new Insets(20));

        Label header = new Label("Home - District Overview");
        header.setFont(Font.font("Arial", FontWeight.BOLD, 26));
        header.setTextFill(Color.WHITE);
        header.setPadding(new Insets(0, 0, 10, 0));

        TextField search = new TextField();
        search.setPromptText("Search District...");
        search.setMaxWidth(300);
        search.setStyle(String.format("-fx-background-color: %s; -fx-text-fill: %s; -fx-border-color: %s; -fx-prompt-text-fill: %s;", "#1C2A3E", "#FFFFFF", "#3A506B", "#B0C4DE"));

        TableView<DistrictData> table = new TableView<>();
        table.setPrefWidth(600);
        table.setStyle(String.format("-fx-background-color: %s; -fx-border-color: %s;", "#1C2A3E", "#3A506B"));

        TableColumn<DistrictData, String> distCol = new TableColumn<>("District");
        TableColumn<DistrictData, String> locCol = new TableColumn<>("Location");
        TableColumn<DistrictData, Integer> amtCol = new TableColumn<>("Amount");
        distCol.setCellValueFactory(new PropertyValueFactory<>("district"));
        locCol.setCellValueFactory(new PropertyValueFactory<>("location"));
        amtCol.setCellValueFactory(new PropertyValueFactory<>("amount"));
        table.getColumns().addAll(distCol, locCol, amtCol);

        List<DistrictData> all = readDataFromCSV();
        table.getItems().addAll(all);

        TextField amountField = new TextField();
        amountField.setPromptText("Enter Investment Amount");
        amountField.setStyle(String.format("-fx-background-color: %s; -fx-text-fill: %s; -fx-border-color: %s; -fx-prompt-text-fill: %s;", "#1C2A3E", "#FFFFFF", "#3A506B", "#B0C4DE"));

        Button submitBtn = new Button("Calculate Profit");
        String submitIdle = "-fx-background-color: #00C853; -fx-text-fill: white; -fx-font-size: 14px; -fx-font-weight: bold; -fx-padding: 8 16; -fx-background-radius: 8; -fx-cursor: hand;";
        String submitHover = "-fx-background-color: #00A946; -fx-text-fill: white; -fx-font-size: 14px; -fx-font-weight: bold; -fx-padding: 8 16; -fx-background-radius: 8; -fx-cursor: hand;";
        submitBtn.setStyle(submitIdle);
        submitBtn.setOnMouseEntered(e -> submitBtn.setStyle(submitHover));
        submitBtn.setOnMouseExited(e -> submitBtn.setStyle(submitIdle));


        HBox inputBox = new HBox(10, amountField, submitBtn);
        inputBox.setAlignment(Pos.CENTER);

        submitBtn.setOnAction(e -> {
            DistrictData selected = table.getSelectionModel().getSelectedItem();
            String investmentText = amountField.getText();

            if (selected == null) {
                Alert alert = new Alert(Alert.AlertType.WARNING, "Please select a district from the table!");
                alert.showAndWait();
                return;
            }
            if (investmentText.isEmpty()) {
                Alert alert = new Alert(Alert.AlertType.WARNING, "Please enter an investment amount!");
                alert.showAndWait();
                return;
            }

            try {
                int investment = Integer.parseInt(investmentText);
                String districtName = selected.getDistrict();
                Main_calc calculator = new Main_calc(investment, districtName);
                calculator.load();

                if (!calculator.valid()) {
                    Alert alert = new Alert(Alert.AlertType.ERROR, "Could not find data for district: " + districtName);
                    alert.showAndWait();
                    if (pieChartData != null) {
                        pieChartData.clear();
                        profitPieChart.setTitle("Profit Breakdown");
                    }
                    return;
                }

                String source1Result = calculator.source_1();
                String source2Result = calculator.source_2();
                String source3Result = calculator.source_3();
                String finalSuggestion = calculator.suggestion();

                if (reportDistrictLabel != null) {
                    reportDistrictLabel.setText("District: " + districtName);
                    reportInvestmentLabel.setText("Investment: " + investment);
                    suggestionTextLabel.setText(finalSuggestion);
                    source1DetailLabel.setText(source1Result);
                    source2DetailLabel.setText(source2Result);
                    source3DetailLabel.setText(source3Result);
                }

                List<Double> profits = calculator.getMaxProfCurr();
                if (profitPieChart != null && profits != null && profits.size() == 3) {

                    pieChartData.clear();
                    double profit1 = profits.get(0) > 0 ? profits.get(0) : 0.0;
                    double profit2 = profits.get(1) > 0 ? profits.get(1) : 0.0;
                    double profit3 = profits.get(2) > 0 ? profits.get(2) : 0.0;

                    if (profit1 > 0) pieChartData.add(new PieChart.Data("Source 1", profit1));
                    if (profit2 > 0) pieChartData.add(new PieChart.Data("Source 2", profit2));
                    if (profit3 > 0) pieChartData.add(new PieChart.Data("Source 3", profit3));

                    profitPieChart.setTitle("Profit Breakdown for " + districtName);
                }

                Alert alert = new Alert(Alert.AlertType.INFORMATION, "Calculation Complete! \nCheck the 'Suggestion' and 'Graph' pages.");
                alert.showAndWait();
                amountField.clear();

            } catch (NumberFormatException ex) {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Enter a valid number for Investment Amount!");
                alert.showAndWait();
            } catch (Exception ex) {
                Alert alert = new Alert(Alert.AlertType.ERROR, "An error occurred during calculation: " + ex.getMessage());
                alert.showAndWait();
                ex.printStackTrace();
            }
        });

        search.textProperty().addListener((obs, oldVal, newVal) -> {
            table.getItems().setAll(all.stream()
                    .filter(d -> d.getDistrict().toLowerCase().contains(newVal.toLowerCase()))
                    .collect(Collectors.toList()));
        });

        box.getChildren().addAll(header, search, table, inputBox);
        return box;
    }

    // ---------------- GRAPH PAGE ----------------
    private VBox createGraphPage() {
        VBox box = new VBox(15);
        box.setAlignment(Pos.TOP_CENTER);
        box.setPadding(new Insets(25));

        Label lbl = new Label("📊 Profitability Graph");
        lbl.setFont(Font.font("Arial", FontWeight.BOLD, 26));
        lbl.setTextFill(Color.WHITE);
        VBox.setMargin(lbl, new Insets(0, 0, 10, 0));

        pieChartData = FXCollections.observableArrayList();
        profitPieChart = new PieChart(pieChartData);
        profitPieChart.setTitle("Profit Breakdown");
        profitPieChart.setLegendVisible(true);
        profitPieChart.setLabelsVisible(true);

        profitPieChart.getStylesheets().add(
                "data:text/css," +
                        ".chart-pie-label { -fx-fill: white; -fx-font-size: 13px; }" +
                        ".chart-legend { -fx-background-color: rgba(0,0,0,0.3); }" +
                        ".chart-legend-item { -fx-text-fill: white; }" +
                        ".chart-title { -fx-text-fill: white; -fx-font-size: 18px; }" +
                        ".chart-no-data { -fx-text-fill: #B0C4DE; -fx-font-size: 16px; }"
        );

        box.getChildren().addAll(lbl, profitPieChart);
        VBox.setVgrow(profitPieChart, Priority.ALWAYS);

        return box;
    }


    // ---------------- SUGGESTION PAGE ---------------
    private VBox createSuggestionPage() {
        VBox box = new VBox(20);
        box.setAlignment(Pos.TOP_CENTER);
        box.setPadding(new Insets(25));

        Label lbl = new Label("💡 Profitability Report");
        lbl.setFont(Font.font("Arial", FontWeight.BOLD, 26));
        lbl.setTextFill(Color.WHITE);
        VBox.setMargin(lbl, new Insets(0, 0, 10, 0));

        reportDistrictLabel = new Label("District: (Please run a calculation)");
        reportInvestmentLabel = new Label("Investment: (Please run a calculation)");
        for (Label l : Arrays.asList(reportDistrictLabel, reportInvestmentLabel)) {
            l.setFont(Font.font("Arial", FontWeight.NORMAL, 16));
            l.setTextFill(Color.web("#B0C4DE"));
        }
        HBox inputsBox = new HBox(40, reportDistrictLabel, reportInvestmentLabel);
        inputsBox.setAlignment(Pos.CENTER);

        VBox suggestionBox = new VBox(10);
        suggestionBox.setAlignment(Pos.CENTER_LEFT);
        suggestionBox.setPadding(new Insets(20));
        suggestionBox.setStyle(String.format(
                "-fx-background-color: rgba(0, 0, 0, 0.4); -fx-background-radius: 10; -fx-border-color: %s; -fx-border-width: 1; -fx-border-radius: 10;",
                "#0078D7"
        ));

        Label suggestionTitle = new Label("Final Suggestion");
        suggestionTitle.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        suggestionTitle.setTextFill(Color.web("#00C853"));

        suggestionTextLabel = new Label("Run a calculation from the 'Home' page to see results.");
        suggestionTextLabel.setFont(Font.font("Arial", FontWeight.NORMAL, 15));
        suggestionTextLabel.setTextFill(Color.WHITE);
        suggestionTextLabel.setWrapText(true);

        suggestionBox.getChildren().addAll(suggestionTitle, suggestionTextLabel);

        Label detailsHeader = new Label("Calculation Details");
        detailsHeader.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        detailsHeader.setTextFill(Color.WHITE);
        VBox.setMargin(detailsHeader, new Insets(15, 0, 5, 0));

        source1DetailLabel = createDetailLabel();
        source2DetailLabel = createDetailLabel();
        source3DetailLabel = createDetailLabel();

        TitledPane source1Pane = new TitledPane("Source 1 Report", source1DetailLabel);
        TitledPane source2Pane = new TitledPane("Source 2 Report", source2DetailLabel);
        TitledPane source3Pane = new TitledPane("Source 3 Report", source3DetailLabel);

        Accordion accordion = new Accordion(source1Pane, source2Pane, source3Pane);
        accordion.setStyle(String.format("-fx-background-color: %s; -fx-text-fill: %s;", "#1C2A3E", "#FFFFFF"));


        VBox reportContent = new VBox(15, inputsBox, suggestionBox, detailsHeader, accordion);
        reportContent.setAlignment(Pos.TOP_CENTER);
        reportContent.setStyle("-fx-background-color: transparent;");
        reportContent.setPadding(new Insets(10));

        ScrollPane scrollPane = new ScrollPane(reportContent);
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background-color: transparent; -fx-background: transparent;");

        box.getChildren().addAll(lbl, scrollPane);
        return box;
    }

    private Label createDetailLabel() {
        Label label = new Label("-");
        label.setTextFill(Color.web("#B0C4DE"));
        label.setFont(Font.font("Monospaced", FontWeight.NORMAL, 13));
        label.setWrapText(true);
        label.setPadding(new Insets(10));
        return label;
    }

    // ---------------- CSV DATA HANDLING ----------------
    private List<DistrictData> readDataFromCSV() {
        List<DistrictData> list = new ArrayList<>();
        try (InputStream is = getClass().getResourceAsStream("/data.csv")) {
            if (is == null) {
                System.err.println("CRITICAL ERROR: data.csv not found in resources!");
                return list;
            }
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            String line = reader.readLine();
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 3) {
                    try {
                        String district = parts[0];
                        String location = parts[1];
                        int amount = parts[2].isEmpty() ? 0 : Integer.parseInt(parts[2]);
                        list.add(new DistrictData(district, location, amount));
                    } catch (NumberFormatException e) {
                        System.err.println("Skipping bad row in data.csv: " + line);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return list;
    }

    // ---------------- DATA CLASS ----------------
    public static class DistrictData {
        private String district;
        private String location;
        private int amount;
        public DistrictData(String district, String location, int amount) {
            this.district = district;
            this.location = location;
            this.amount = amount;
        }
        public String getDistrict() { return district; }
        public String getLocation() { return location; }
        public int getAmount() { return amount; }
        public void setAmount(int amount) { this.amount = amount; }
    }

    public static void main(String[] args) {
        launch(args);
    }
}